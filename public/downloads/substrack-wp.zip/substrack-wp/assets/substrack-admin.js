/* global jQuery, substrackAdmin */

/**
 * Substrack admin page JS.
 * Handles two AJAX actions:
 *   1. Test API Connection  — calls substrack_test_connection
 *   2. Clear Subscription Cache — calls substrack_clear_cache
 *
 * Both nonce and ajaxUrl are injected by wp_localize_script() in
 * Substrack_Admin::enqueue_admin_scripts().
 */
( function ( $ ) {
    'use strict';

    $( document ).ready( function () {
        const resultEl = $( '#substrack-action-result' );

        function setResult( message, isError ) {
            resultEl
                .text( message )
                .css( 'color', isError ? '#dc3232' : '#46b450' );
        }

        function clearResult() {
            resultEl.text( '' );
        }

        // ── Test Connection ──────────────────────────────────────────────────

        $( '#substrack-test-btn' ).on( 'click', function () {
            const btn = $( this );

            clearResult();
            btn.prop( 'disabled', true ).text( substrackAdmin.testingText );

            $.post( substrackAdmin.ajaxUrl, {
                action: 'substrack_test_connection',
                nonce:  substrackAdmin.nonce,
            } )
                .done( function ( response ) {
                    if ( response.success ) {
                        setResult( '✓ ' + response.data, false );
                    } else {
                        setResult( '✗ ' + response.data, true );
                    }
                } )
                .fail( function ( xhr ) {
                    setResult(
                        '✗ Network error (' + xhr.status + '). Check your server logs.',
                        true
                    );
                } )
                .always( function () {
                    btn.prop( 'disabled', false ).text( 'Test API Connection' );
                } );
        } );

        // ── Clear Cache ──────────────────────────────────────────────────────

        $( '#substrack-clear-cache-btn' ).on( 'click', function () {
            const btn = $( this );

            clearResult();
            btn.prop( 'disabled', true ).text( substrackAdmin.clearingText );

            $.post( substrackAdmin.ajaxUrl, {
                action: 'substrack_clear_cache',
                nonce:  substrackAdmin.nonce,
            } )
                .done( function ( response ) {
                    if ( response.success ) {
                        setResult( '✓ ' + response.data, false );
                    } else {
                        setResult( '✗ ' + response.data, true );
                    }
                } )
                .fail( function ( xhr ) {
                    setResult(
                        '✗ Network error (' + xhr.status + ').',
                        true
                    );
                } )
                .always( function () {
                    btn.prop( 'disabled', false ).text( 'Clear Subscription Cache' );
                } );
        } );
    } );
} )( jQuery );
