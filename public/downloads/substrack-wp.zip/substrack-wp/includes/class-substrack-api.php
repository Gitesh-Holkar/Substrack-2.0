<?php
/**
 * Substrack_API
 *
 * All HTTP communication with the Substrack REST API.
 * Every call is made from PHP (server-side). The API key is never sent
 * to the browser. Results are cached in WordPress transients to minimise
 * outbound requests and keep page load times acceptable.
 *
 * API contract this class depends on:
 *   POST {app_url}/api/v1/subscriptions/check
 *     Header:  X-API-Key: sub_live_...
 *     Body:    { "email": "user@example.com" }
 *     Returns: { success: bool, data: { has_subscription: bool, subscriber: object|null } }
 *
 *   GET  {app_url}/api/v1/plans
 *     Header:  X-API-Key: sub_live_...
 *     Returns: { success: bool, data: [ ...plans ] }
 *     Plan shape: { id, name, description, price (numeric decimal), currency,
 *                   billing_cycle, features (array), is_active }
 *
 * Checkout URL pattern (confirmed in Substrack plans/page.tsx copyPaymentLink):
 *   {app_url}/subscribe/{plan_id}
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Substrack_API {

    private string $api_key;
    private string $app_url;
    private int    $cache_duration_seconds;

    public function __construct() {
        $this->api_key               = (string) get_option( 'substrack_api_key', '' );
        $this->app_url               = rtrim( (string) get_option( 'substrack_app_url', '' ), '/' );
        $cache_minutes               = max( 1, (int) get_option( 'substrack_cache_duration', 5 ) );
        $this->cache_duration_seconds = $cache_minutes * MINUTE_IN_SECONDS;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Public methods
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Check whether an email has an active subscription under this merchant.
     *
     * Returns a normalised array so callers never have to touch raw API shapes:
     *   [
     *     'has_subscription' => bool,
     *     'subscriber'       => array|null,   // full subscriber object from API
     *     'error'            => string|null,  // human-readable, null on success
     *   ]
     *
     * The result is cached for $cache_duration_seconds. Cache key is derived
     * from the md5 of the lowercase email so the key itself is never stored
     * in plaintext in wp_options.
     *
     * @param string $email
     * @return array{ has_subscription: bool, subscriber: array|null, error: string|null }
     */
    public function check_subscription( string $email ): array {
        $not_configured = $this->not_configured_result();
        if ( $not_configured !== null ) {
            return $not_configured;
        }

        $email     = strtolower( trim( $email ) );
        $cache_key = 'substrack_sub_' . md5( $email );
        $cached    = get_transient( $cache_key );

        if ( $cached !== false ) {
            return $cached;
        }

        $response = wp_remote_post(
            $this->app_url . '/api/v1/subscriptions/check',
            [
                'timeout'     => 10,
                'redirection' => 3,
                'headers'     => [
                    'Content-Type' => 'application/json',
                    'X-API-Key'    => $this->api_key,
                ],
                'body' => wp_json_encode( [ 'email' => $email ] ),
            ]
        );

        if ( is_wp_error( $response ) ) {
            // Do NOT cache network errors — transient failure should retry next request.
            return [
                'has_subscription' => false,
                'subscriber'       => null,
                'error'            => $response->get_error_message(),
            ];
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );

        if ( $code !== 200 || ! isset( $data['success'] ) || ! $data['success'] ) {
            // API returned an explicit error — do not cache.
            return [
                'has_subscription' => false,
                'subscriber'       => null,
                'error'            => $data['error'] ?? ( 'API error (HTTP ' . $code . ')' ),
            ];
        }

        $result = [
            'has_subscription' => (bool) ( $data['data']['has_subscription'] ?? false ),
            'subscriber'       => $data['data']['subscriber'] ?? null,
            'error'            => null,
        ];

        // Only cache successful, definitive responses (both true and false).
        set_transient( $cache_key, $result, $this->cache_duration_seconds );

        return $result;
    }

    /**
     * Fetch all active plans for this merchant.
     * Cached for 15 minutes — plans change rarely compared to subscriptions.
     *
     * Returns an array of plan objects or an empty array on any failure.
     * Plan price is a float (INR decimal e.g. 999.00) — NOT paise integers.
     *
     * @return array<int, array<string, mixed>>
     */
    public function get_plans(): array {
        if ( $this->not_configured_result() !== null ) {
            return [];
        }

        $cache_key = 'substrack_plans';
        $cached    = get_transient( $cache_key );

        if ( $cached !== false ) {
            return $cached;
        }

        $response = wp_remote_get(
            $this->app_url . '/api/v1/plans',
            [
                'timeout'     => 10,
                'redirection' => 3,
                'headers'     => [
                    'X-API-Key' => $this->api_key,
                ],
            ]
        );

        if ( is_wp_error( $response ) ) {
            return [];
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );

        if ( $code !== 200 || ! isset( $data['data'] ) || ! is_array( $data['data'] ) ) {
            return [];
        }

        $plans = $data['data'];
        set_transient( $cache_key, $plans, 15 * MINUTE_IN_SECONDS );

        return $plans;
    }

    /**
     * Return the hosted checkout URL for a given plan.
     * Confirmed pattern: {app_url}/subscribe/{plan_id}
     * Source: Substrack plans/page.tsx — copyPaymentLink().
     *
     * @param string $plan_id UUID of the subscription plan.
     * @return string Full URL.
     */
    public function get_checkout_url( string $plan_id ): string {
        return $this->app_url . '/subscribe/' . rawurlencode( $plan_id );
    }

    /**
     * Validate the API key and app URL by making a real API request.
     * Used only from the admin settings page.
     *
     * @return true|string Returns true on success, or an error message string.
     */
    public function test_connection(): bool|string {
        if ( empty( $this->api_key ) ) {
            return 'API key is empty. Enter your key and save settings first.';
        }
        if ( empty( $this->app_url ) ) {
            return 'App URL is empty. Enter your Substrack app URL and save settings first.';
        }
        if ( ! str_starts_with( $this->api_key, 'sub_live_' ) ) {
            return 'API key format is wrong. It must start with sub_live_';
        }

        $response = wp_remote_get(
            $this->app_url . '/api/v1/plans',
            [
                'timeout' => 10,
                'headers' => [ 'X-API-Key' => $this->api_key ],
            ]
        );

        if ( is_wp_error( $response ) ) {
            return 'Could not reach ' . $this->app_url . ': ' . $response->get_error_message();
        }

        $code = (int) wp_remote_retrieve_response_code( $response );

        if ( $code === 401 ) {
            return 'API key rejected (401). Check the key in Settings → API Keys inside Substrack.';
        }
        if ( $code !== 200 ) {
            return 'App returned HTTP ' . $code . '. Verify the App URL is correct.';
        }

        return true;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Private helpers
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Return an error result array if the plugin is not configured, or null
     * if it is correctly configured and calls can proceed.
     *
     * @return array{ has_subscription: bool, subscriber: null, error: string }|null
     */
    private function not_configured_result(): ?array {
        if ( empty( $this->api_key ) || empty( $this->app_url ) ) {
            return [
                'has_subscription' => false,
                'subscriber'       => null,
                'error'            => 'Substrack plugin is not configured. Go to Settings → Substrack.',
            ];
        }
        return null;
    }
}
