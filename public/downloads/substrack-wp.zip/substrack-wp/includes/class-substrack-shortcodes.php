<?php
/**
 * Substrack_Shortcodes
 *
 * Registers all four public shortcodes:
 *
 *   [substrack_gated]           Content gating — subscribers see content, others see fallback.
 *   [substrack_subscribe_button] A link to Substrack checkout for a specific plan.
 *   [substrack_plans]           Renders all active plans as cards.
 *   [substrack_status]          Inline subscription status for the current user.
 *
 * All subscription checks are performed server-side via Substrack_API.
 * The API key never reaches the browser.
 *
 * Email source: WordPress logged-in user's email (wp_get_current_user()->user_email).
 * If the user is not logged in, subscription is assumed to be absent — no API call is made.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Substrack_Shortcodes {

    private Substrack_API $api;

    public function __construct() {
        $this->api = new Substrack_API();

        add_shortcode( 'substrack_gated',            [ $this, 'shortcode_gated' ] );
        add_shortcode( 'substrack_subscribe_button', [ $this, 'shortcode_subscribe_button' ] );
        add_shortcode( 'substrack_plans',            [ $this, 'shortcode_plans' ] );
        add_shortcode( 'substrack_status',           [ $this, 'shortcode_status' ] );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // [substrack_gated plan_id="" message=""]...[/substrack_gated]
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Attributes:
     *   plan_id  (string)  Optional. UUID of the plan whose checkout to link in the fallback.
     *                      If empty, {subscribe_url} in the global message falls back to '#'.
     *   message  (string)  Optional. HTML message for non-subscribers, overrides global setting.
     *                      Supports {subscribe_url} and {plan_name} placeholders.
     *
     * Behaviour:
     *   - Not logged in → login prompt (no API call).
     *   - Logged in, active subscription → inner content rendered.
     *   - Logged in, no active subscription → fallback message.
     */
    public function shortcode_gated( array $atts, string $content = '' ): string {
        $atts = shortcode_atts(
            [
                'plan_id' => '',
                'message' => '',
            ],
            $atts,
            'substrack_gated'
        );

        // Not logged in — show login prompt, skip API call entirely.
        if ( ! is_user_logged_in() ) {
            return sprintf(
                '<div class="substrack-gated substrack-login-required"><p>%s</p></div>',
                wp_kses(
                    sprintf(
                        /* translators: %s: login URL */
                        __( 'Please <a href="%s">log in</a> to view this content.', 'substrack-wp' ),
                        esc_url( wp_login_url( get_permalink() ) )
                    ),
                    [ 'a' => [ 'href' => [] ] ]
                )
            );
        }

        $result = $this->get_current_subscription();

        if ( $result['has_subscription'] ) {
            return '<div class="substrack-gated substrack-access-granted">'
                . do_shortcode( $content )
                . '</div>';
        }

        // Build fallback message.
        $raw_message = ! empty( $atts['message'] )
            ? $atts['message']
            : (string) get_option(
                'substrack_not_subscribed_message',
                '<p>This content is for subscribers only. <a href="{subscribe_url}">Subscribe now</a> to get access.</p>'
            );

        $message = $this->resolve_message_placeholders( $raw_message, $atts['plan_id'] );

        return '<div class="substrack-gated substrack-no-access">' . $message . '</div>';
    }

    // ─────────────────────────────────────────────────────────────────────────
    // [substrack_subscribe_button plan_id="" text="Subscribe Now" class=""]
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Attributes:
     *   plan_id  (string)  Required. UUID of the subscription plan.
     *   text     (string)  Button / link text. Default: "Subscribe Now".
     *   class    (string)  Additional CSS class(es) for the <a> element.
     *
     * Renders a plain <a> tag pointing to the Substrack hosted checkout.
     * Opens in a new tab so the user does not lose their current WordPress page.
     */
    public function shortcode_subscribe_button( array $atts ): string {
        $atts = shortcode_atts(
            [
                'plan_id' => '',
                'text'    => __( 'Subscribe Now', 'substrack-wp' ),
                'class'   => '',
            ],
            $atts,
            'substrack_subscribe_button'
        );

        if ( empty( $atts['plan_id'] ) ) {
            if ( current_user_can( 'manage_options' ) ) {
                return '<p style="color:red;">[substrack_subscribe_button] — <code>plan_id</code> is required.</p>';
            }
            return '';
        }

        $url   = $this->api->get_checkout_url( $atts['plan_id'] );
        $class = trim( 'substrack-subscribe-btn ' . sanitize_html_class( $atts['class'] ) );

        return sprintf(
            '<a href="%s" class="%s" target="_blank" rel="noopener noreferrer">%s</a>',
            esc_url( $url ),
            esc_attr( $class ),
            esc_html( $atts['text'] )
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // [substrack_plans]
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Renders all active plans returned by GET /api/v1/plans.
     *
     * If the current user is a subscriber, their current plan gets a
     * "Current Plan" badge instead of a subscribe button.
     *
     * Price is formatted as ₹X,XXX.XX — the API returns a decimal float,
     * NOT paise integers. Do not divide by 100.
     *
     * No attributes.
     */
    public function shortcode_plans( array $atts ): string {
        $plans = $this->api->get_plans();

        if ( empty( $plans ) ) {
            return '<p class="substrack-no-plans">'
                . esc_html__( 'No subscription plans are currently available.', 'substrack-wp' )
                . '</p>';
        }

        $current_sub     = $this->get_current_subscription();
        $current_plan_id = $current_sub['subscriber']['plan']['id'] ?? '';

        ob_start();
        ?>
        <div class="substrack-plans">
            <?php foreach ( $plans as $plan ) :
                if ( empty( $plan['id'] ) || empty( $plan['name'] ) ) {
                    continue;
                }

                $plan_id     = (string) $plan['id'];
                $is_current  = ( $current_plan_id === $plan_id );
                $price       = number_format( (float) ( $plan['price'] ?? 0 ), 2 );
                $cycle       = (string) ( $plan['billing_cycle'] ?? '' );
                $description = (string) ( $plan['description'] ?? '' );
                $features    = is_array( $plan['features'] ?? null ) ? $plan['features'] : [];
                $checkout    = $this->api->get_checkout_url( $plan_id );
            ?>
                <div class="substrack-plan<?php echo $is_current ? ' substrack-plan--current' : ''; ?>">

                    <h3 class="substrack-plan__name">
                        <?php echo esc_html( $plan['name'] ); ?>
                    </h3>

                    <?php if ( $description !== '' ) : ?>
                        <p class="substrack-plan__description">
                            <?php echo esc_html( $description ); ?>
                        </p>
                    <?php endif; ?>

                    <p class="substrack-plan__price">
                        ₹<?php echo esc_html( $price ); ?>
                        <?php if ( $cycle !== '' ) : ?>
                            <span class="substrack-plan__cycle">
                                / <?php echo esc_html( $cycle ); ?>
                            </span>
                        <?php endif; ?>
                    </p>

                    <?php if ( ! empty( $features ) ) : ?>
                        <ul class="substrack-plan__features">
                            <?php foreach ( $features as $feature ) : ?>
                                <li><?php echo esc_html( (string) $feature ); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>

                    <?php if ( $is_current ) : ?>
                        <span class="substrack-plan__badge">
                            <?php esc_html_e( '✓ Your Current Plan', 'substrack-wp' ); ?>
                        </span>
                    <?php else : ?>
                        <a href="<?php echo esc_url( $checkout ); ?>"
                           class="substrack-plan__btn"
                           target="_blank"
                           rel="noopener noreferrer">
                            <?php esc_html_e( 'Subscribe', 'substrack-wp' ); ?>
                        </a>
                    <?php endif; ?>

                </div>
            <?php endforeach; ?>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // [substrack_status]
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Inline text showing the current user's subscription status.
     * Examples:
     *   ✓ Subscribed — Pro Plan
     *   No active subscription
     *   Not logged in
     *
     * Useful in headers, account pages, or navigation bars.
     * No attributes.
     */
    public function shortcode_status( array $atts ): string {
        if ( ! is_user_logged_in() ) {
            return '<span class="substrack-status substrack-status--guest">'
                . esc_html__( 'Not logged in', 'substrack-wp' )
                . '</span>';
        }

        $result = $this->get_current_subscription();

        if ( $result['has_subscription'] ) {
            $plan_name = (string) ( $result['subscriber']['plan']['name'] ?? 'Active Plan' );
            return '<span class="substrack-status substrack-status--active">'
                . esc_html( '✓ ' . __( 'Subscribed — ', 'substrack-wp' ) . $plan_name )
                . '</span>';
        }

        return '<span class="substrack-status substrack-status--inactive">'
            . esc_html__( 'No active subscription', 'substrack-wp' )
            . '</span>';
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Private helpers
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Return the subscription result for the currently logged-in WordPress user.
     * Returns a "no subscription" result if the user is not logged in —
     * callers must guard with is_user_logged_in() before calling this if they
     * need to distinguish "not logged in" from "logged in but not subscribed".
     *
     * @return array{ has_subscription: bool, subscriber: array|null, error: string|null }
     */
    private function get_current_subscription(): array {
        $email = $this->get_current_user_email();

        if ( empty( $email ) ) {
            return [
                'has_subscription' => false,
                'subscriber'       => null,
                'error'            => null,
            ];
        }

        return $this->api->check_subscription( $email );
    }

    /**
     * Get the email address of the currently logged-in WordPress user.
     * Returns an empty string if not logged in or email is not set.
     */
    private function get_current_user_email(): string {
        if ( ! is_user_logged_in() ) {
            return '';
        }
        $user = wp_get_current_user();
        return isset( $user->user_email ) ? (string) $user->user_email : '';
    }

    /**
     * Replace {subscribe_url} and {plan_name} placeholders in a message string.
     * Runs the result through wp_kses_post so arbitrary HTML is safe to output.
     *
     * @param string $message  Raw message possibly containing placeholders.
     * @param string $plan_id  Plan UUID to build the checkout URL. Empty = '#'.
     * @return string          Sanitized HTML ready for echo.
     */
    private function resolve_message_placeholders( string $message, string $plan_id ): string {
        $subscribe_url = ! empty( $plan_id )
            ? $this->api->get_checkout_url( $plan_id )
            : '#';

        // Resolve plan name if a plan_id is supplied.
        $plan_name = '';
        if ( ! empty( $plan_id ) ) {
            $plans = $this->api->get_plans();
            foreach ( $plans as $plan ) {
                if ( isset( $plan['id'] ) && (string) $plan['id'] === $plan_id ) {
                    $plan_name = (string) ( $plan['name'] ?? '' );
                    break;
                }
            }
        }

        $message = str_replace( '{subscribe_url}', esc_url( $subscribe_url ), $message );
        $message = str_replace( '{plan_name}',     esc_html( $plan_name ),    $message );

        return wp_kses_post( $message );
    }
}
