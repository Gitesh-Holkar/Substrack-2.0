<?php
/**
 * Substrack_Admin
 *
 * Registers the Settings page under Settings → Substrack.
 * Handles settings registration, admin notice when unconfigured,
 * AJAX test-connection, and AJAX cache-clear.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Substrack_Admin {

    public function __construct() {
        add_action( 'admin_menu',            [ $this, 'add_settings_page' ] );
        add_action( 'admin_init',            [ $this, 'register_settings' ] );
        add_action( 'admin_notices',         [ $this, 'configuration_notice' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_scripts' ] );
        add_action( 'wp_ajax_substrack_test_connection', [ $this, 'ajax_test_connection' ] );
        add_action( 'wp_ajax_substrack_clear_cache',     [ $this, 'ajax_clear_cache' ] );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Menu & settings registration
    // ─────────────────────────────────────────────────────────────────────────

    public function add_settings_page(): void {
        add_options_page(
            'Substrack Settings',
            'Substrack',
            'manage_options',
            'substrack',
            [ $this, 'render_settings_page' ]
        );
    }

    public function register_settings(): void {
        register_setting( 'substrack_settings', 'substrack_api_key', [
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => '',
        ] );
        register_setting( 'substrack_settings', 'substrack_app_url', [
            'type'              => 'string',
            'sanitize_callback' => [ $this, 'sanitize_app_url' ],
            'default'           => '',
        ] );
        register_setting( 'substrack_settings', 'substrack_cache_duration', [
            'type'              => 'integer',
            'sanitize_callback' => [ $this, 'sanitize_cache_duration' ],
            'default'           => 5,
        ] );
        register_setting( 'substrack_settings', 'substrack_not_subscribed_message', [
            'type'              => 'string',
            'sanitize_callback' => 'wp_kses_post',
            'default'           => '<p>This content is for subscribers only. <a href="{subscribe_url}">Subscribe now</a> to get access.</p>',
        ] );
    }

    /**
     * Strip trailing slashes and validate the URL scheme.
     */
    public function sanitize_app_url( string $raw ): string {
        $url = esc_url_raw( rtrim( trim( $raw ), '/' ) );
        // Must be https in production; allow http only for localhost dev.
        if ( ! empty( $url ) && ! preg_match( '#^https?://#i', $url ) ) {
            add_settings_error(
                'substrack_app_url',
                'invalid_url',
                'App URL must start with https://'
            );
            return '';
        }
        return $url;
    }

    /**
     * Clamp cache duration to 1–60 minutes.
     */
    public function sanitize_cache_duration( mixed $raw ): int {
        return min( 60, max( 1, (int) $raw ) );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Admin notice
    // ─────────────────────────────────────────────────────────────────────────

    public function configuration_notice(): void {
        $api_key = get_option( 'substrack_api_key', '' );
        $app_url = get_option( 'substrack_app_url', '' );

        if ( ! empty( $api_key ) && ! empty( $app_url ) ) {
            return;
        }

        $settings_url = admin_url( 'options-general.php?page=substrack' );
        printf(
            '<div class="notice notice-warning"><p>%s</p></div>',
            wp_kses(
                sprintf(
                    /* translators: %s: link to settings page */
                    __( '<strong>Substrack:</strong> Plugin is not configured. <a href="%s">Configure it now →</a>', 'substrack-wp' ),
                    esc_url( $settings_url )
                ),
                [ 'strong' => [], 'a' => [ 'href' => [] ] ]
            )
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Scripts
    // ─────────────────────────────────────────────────────────────────────────

    public function enqueue_admin_scripts( string $hook ): void {
        if ( $hook !== 'settings_page_substrack' ) {
            return;
        }
        wp_enqueue_script(
            'substrack-admin',
            SUBSTRACK_PLUGIN_URL . 'assets/substrack-admin.js',
            [ 'jquery' ],
            SUBSTRACK_VERSION,
            true
        );
        wp_localize_script( 'substrack-admin', 'substrackAdmin', [
            'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
            'nonce'        => wp_create_nonce( 'substrack_admin_nonce' ),
            'testingText'  => __( 'Testing…', 'substrack-wp' ),
            'clearingText' => __( 'Clearing…', 'substrack-wp' ),
        ] );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AJAX handlers
    // ─────────────────────────────────────────────────────────────────────────

    public function ajax_test_connection(): void {
        check_ajax_referer( 'substrack_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Insufficient permissions.' );
        }

        $api    = new Substrack_API();
        $result = $api->test_connection();

        if ( $result === true ) {
            wp_send_json_success( 'Connection successful. API key is valid.' );
        } else {
            wp_send_json_error( $result );
        }
    }

    public function ajax_clear_cache(): void {
        check_ajax_referer( 'substrack_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Insufficient permissions.' );
        }

        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $deleted = (int) $wpdb->query(
            "DELETE FROM {$wpdb->options}
             WHERE option_name LIKE '_transient_substrack\_%'
                OR option_name LIKE '_transient_timeout_substrack\_%'"
        );

        wp_send_json_success( 'Cleared ' . $deleted . ' cache entries.' );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Settings page HTML
    // ─────────────────────────────────────────────────────────────────────────

    public function render_settings_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $api_key          = (string) get_option( 'substrack_api_key', '' );
        $app_url          = (string) get_option( 'substrack_app_url', '' );
        $cache_duration   = (int)    get_option( 'substrack_cache_duration', 5 );
        $fallback_message = (string) get_option(
            'substrack_not_subscribed_message',
            '<p>This content is for subscribers only. <a href="{subscribe_url}">Subscribe now</a> to get access.</p>'
        );
        ?>
        <div class="wrap">
            <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>

            <?php settings_errors(); ?>

            <form method="post" action="options.php">
                <?php settings_fields( 'substrack_settings' ); ?>

                <h2>Connection</h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row">
                            <label for="substrack_app_url">App URL</label>
                        </th>
                        <td>
                            <input
                                type="url"
                                id="substrack_app_url"
                                name="substrack_app_url"
                                value="<?php echo esc_attr( $app_url ); ?>"
                                class="regular-text"
                                placeholder="https://your-app.vercel.app"
                                required
                            />
                            <p class="description">
                                The URL where your Substrack Next.js app is deployed.
                                No trailing slash.
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="substrack_api_key">API Key</label>
                        </th>
                        <td>
                            <input
                                type="password"
                                id="substrack_api_key"
                                name="substrack_api_key"
                                value="<?php echo esc_attr( $api_key ); ?>"
                                class="regular-text"
                                placeholder="sub_live_..."
                                autocomplete="new-password"
                                required
                            />
                            <p class="description">
                                Get this from <strong>Substrack Dashboard → Settings → API Keys → Create API Key</strong>.
                                This key is stored in your WordPress database and only ever sent from your server —
                                it never reaches the browser.
                            </p>
                        </td>
                    </tr>
                </table>

                <h2>Behaviour</h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row">
                            <label for="substrack_cache_duration">Cache Duration (minutes)</label>
                        </th>
                        <td>
                            <input
                                type="number"
                                id="substrack_cache_duration"
                                name="substrack_cache_duration"
                                value="<?php echo esc_attr( $cache_duration ); ?>"
                                class="small-text"
                                min="1"
                                max="60"
                            />
                            <p class="description">
                                Per-user subscription status is cached for this many minutes.
                                <strong>Lower</strong> = fresher data, more API requests.
                                <strong>Higher</strong> = faster pages, slower response to cancellations.
                                Recommended: <strong>5</strong>.
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="substrack_not_subscribed_message">
                                Non-Subscriber Message
                            </label>
                        </th>
                        <td>
                            <textarea
                                id="substrack_not_subscribed_message"
                                name="substrack_not_subscribed_message"
                                class="large-text"
                                rows="4"
                            ><?php echo esc_textarea( $fallback_message ); ?></textarea>
                            <p class="description">
                                Shown inside <code>[substrack_gated]</code> blocks when the user is not subscribed.
                                Available placeholders:<br>
                                <code>{subscribe_url}</code> — checkout URL for the plan specified in <code>plan_id=""</code>.<br>
                                <code>{plan_name}</code> — name of the plan specified in <code>plan_id=""</code>.
                            </p>
                        </td>
                    </tr>
                </table>

                <?php submit_button( 'Save Settings' ); ?>
            </form>

            <hr>

            <h2>Test & Maintenance</h2>
            <p>
                <button type="button" id="substrack-test-btn" class="button button-secondary">
                    Test API Connection
                </button>
                &nbsp;
                <button type="button" id="substrack-clear-cache-btn" class="button button-secondary">
                    Clear Subscription Cache
                </button>
                <span id="substrack-action-result" style="margin-left:12px; font-weight:600;"></span>
            </p>
            <p class="description">
                Use <strong>Clear Cache</strong> any time you manually cancel a subscriber in Substrack
                and want WordPress to reflect it immediately without waiting for the cache to expire.
            </p>

            <hr>

            <h2>Shortcode Reference</h2>
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th>Shortcode</th>
                        <th>What it does</th>
                        <th>Full example</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><code>[substrack_gated]…[/substrack_gated]</code></td>
                        <td>Shows inner content only to active subscribers. Everyone else sees the fallback message.</td>
                        <td><code>[substrack_gated plan_id="YOUR-PLAN-UUID"]Members-only content here.[/substrack_gated]</code></td>
                    </tr>
                    <tr>
                        <td><code>[substrack_subscribe_button]</code></td>
                        <td>A link that opens the Substrack checkout page for one specific plan.</td>
                        <td><code>[substrack_subscribe_button plan_id="YOUR-PLAN-UUID" text="Subscribe Now" class="my-css-class"]</code></td>
                    </tr>
                    <tr>
                        <td><code>[substrack_plans]</code></td>
                        <td>Displays all active plans as cards with their price, features, and a subscribe button. Current subscribers see a "Current Plan" badge instead.</td>
                        <td><code>[substrack_plans]</code></td>
                    </tr>
                    <tr>
                        <td><code>[substrack_status]</code></td>
                        <td>Inline text showing the logged-in user's subscription status and plan name.</td>
                        <td><code>[substrack_status]</code></td>
                    </tr>
                </tbody>
            </table>

            <p class="description" style="margin-top:12px;">
                Find your plan UUIDs in <strong>Substrack Dashboard → Plans → Copy Payment Link</strong>
                — the UUID is the last segment of the URL.
            </p>
        </div>
        <?php
    }
}
