<?php
/**
 * Plugin Name:       Substrack
 * Plugin URI:        https://substrack.work.gd
 * Description:       Connect your WordPress site to Substrack. Gate content behind subscriptions, display plans, and link visitors directly to your Substrack checkout — all server-side. Your API key never reaches the browser.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            Substrack
 * License:           GPL-2.0+
 * Text Domain:       substrack-wp
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'SUBSTRACK_VERSION',    '1.0.0' );
define( 'SUBSTRACK_PLUGIN_FILE', __FILE__ );
define( 'SUBSTRACK_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SUBSTRACK_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once SUBSTRACK_PLUGIN_DIR . 'includes/class-substrack-api.php';
require_once SUBSTRACK_PLUGIN_DIR . 'includes/class-substrack-admin.php';
require_once SUBSTRACK_PLUGIN_DIR . 'includes/class-substrack-shortcodes.php';

/**
 * Boot the plugin after all plugins are loaded so hooks from other plugins
 * (WooCommerce, MemberPress, etc.) are available if needed later.
 */
function substrack_init(): void {
    new Substrack_Admin();
    new Substrack_Shortcodes();
}
add_action( 'plugins_loaded', 'substrack_init' );

/**
 * Set safe defaults on first activation.
 * Uses add_option so existing values are never overwritten on re-activation.
 */
function substrack_activate(): void {
    add_option( 'substrack_api_key',                '' );
    add_option( 'substrack_app_url',               '' );
    add_option( 'substrack_cache_duration',        5 );
    add_option( 'substrack_not_subscribed_message',
        '<p>This content is for subscribers only. <a href="{subscribe_url}">Subscribe now</a> to get access.</p>'
    );
}
register_activation_hook( __FILE__, 'substrack_activate' );

/**
 * Clean up ALL cached subscription and plan data when the plugin is deactivated.
 * Prevents stale data if the merchant switches API keys or app URLs.
 */
function substrack_deactivate(): void {
    global $wpdb;

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $wpdb->query(
        "DELETE FROM {$wpdb->options}
         WHERE option_name LIKE '_transient_substrack\_%'
            OR option_name LIKE '_transient_timeout_substrack\_%'"
    );
}
register_deactivation_hook( __FILE__, 'substrack_deactivate' );
